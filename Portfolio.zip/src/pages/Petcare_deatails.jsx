import React from "react";
import logo from "../assets/PetcareDeatail_Img/image_46.png";
import bgImg_1 from "../assets/PetcareDeatail_Img/Macbook_bg.png";
import bgImg_2 from "../assets/PetcareDeatail_Img/Mobile_bg.png";
import petBg from "../assets/PetcareDeatail_Img/Mob_mac.png";
import why_1 from "../assets/PetcareDeatail_Img/smooth_crop.png";
import why_2 from "../assets/PetcareDeatail_Img/Real_crop.png";
import why_3 from "../assets/PetcareDeatail_Img/Mobile_crop.png";
import why_4 from "../assets/PetcareDeatail_Img/secure_crop.png";
import webImg from "../assets/PetcareDeatail_Img/petCare_web.png";
import AlokSharma from "../assets/PetcareDeatail_Img/AlokSharma.png";
import Blackbanner from "../components/HomeComponents/Blackbanner";
import ProtfolioHeader from "../components/ProjectDetailsComponent/ProtfolioHeader.jsx"
import AboutProject from "../components/ProjectDetailsComponent/AboutProject.jsx";
import TechnologiesUsed from "../components/ProjectDetailsComponent/TechnologiesUsed.jsx";
import OurContibution from "../components/ProjectDetailsComponent/OurContibution.jsx";
import CompleteUi from "../components/ProjectDetailsComponent/CompleteUI.jsx";
import ClientSay from "../components/ProjectDetailsComponent/ClientSay.jsx";
import Consult from "../components/ProjectDetailsComponent/Consult.jsx";

function Petcare_deatails() {
  return (
    <>
      <div className="bg-amber-400 ">
        <ProtfolioHeader
          logo={logo}
          pro_name="PAWSITIVE"
          desc1="PETCARE: A SEAMLESS E-COMMERCE"
          desc2="EXPERIENCE FOR PET LOVERS"
          desc3=" Optimized for all devices to provide a perfect shopping experience for pet owners."
          sreen_banner={petBg}
          livepr="https://positive.urbanfusionstudio.com/"
        />

        <AboutProject
         head="ABOUT THE PROJECT"
         desc=" PetCare is an e-commerce platform built to simplify shopping for
                pets. Designed with user convenience in mind, it features an
                intuitive catalog, seamless navigation, and secure payment
                systems."
        img1={why_1}
        img1_name="Smooth Navigation"
        img2={why_2}
        img2_name=" Real-time Updates"
        img3={why_3}
        img3_name=" Mobile-first Design"
        img4={why_4}
        img4_name="Secure Payment"
        />

      <TechnologiesUsed  />

      <OurContibution
      problem="  “ Promotional sales are critical for any e-commerce platform,
                        but they come with their own challenges. The sudden surge in
                        users during these events puts immense pressure on the platform,
                        leading to slow page load times, laggy user interactions, and in
                        some cases, complete crashes. For PetCare, a platform built to
                        cater to pet owners with essential supplies and services, these
                        issues could result in abandoned carts, dissatisfied customers,
                        and lost revenue.”"
      solution=" To address these challenges, we engineered a scalable backend
                        architecture specifically designed to adapt to unpredictable
                        traffic conditions while maintaining peak performance and
                        reliability. Recognizing that even a brief delay or system lag
                        during promotional sales could lead to abandoned carts and
                        frustrated users, we focused on creating a solution that would not
                        only handle traffic surges but also provide a seamless,
                        uninterrupted shopping experience for every customer.”"
        />

       <CompleteUi
       Ui_img={webImg}
       heading=" EXPLORE THE COMPLETE UI DESIGN"
       desc="Take a closer look at the intuitive and user-friendly interface crafted exclusively for PetCare."
       />

       <ClientSay
       client_img={AlokSharma}
       client_name="Alok Mishrma"
       client_post="CEO, Petcare"
       client_msg=" Dharma Tech Solution delivered outstanding results on our project.
              The entire team showcased exceptional skills and professionalism,
              ensuring the project was completed on time and beyond
              expectations. Their seamless communication and proactive approach
              made the collaboration effortless. Every challenge was met with
              innovative solutions, and their dedication to quality was evident
              throughout the process. It’s been a pleasure working with such a
              talented and well-managed team. Highly recommended."

       />

       <Consult/>


        
      </div>
    </>
  );
}

export default Petcare_deatails;
