import React from "react";

const OurContibution = (props) => {
    return (<>
        <div className="mb-20">
            <div className="md:my-20 my-10">
                <p className="md:text-4xl text-2xl font-bold text-white text-center">
                    OUR CONTIBUTION
                </p>
            </div>

            <div className="text-white  mb-16 px-4  w-full grid grid-flow-col gap-6">
                <div className=" w-full flex flex-col justify-center">
                    <div>
                        <p className="font-bold text-white text-xl text-center mb-6">PROBLEM </p>
                        <div className="md:w-4/5 mx-auto">
                            <p className="md:text-lg text-xs md:leading-6 text-justify">
                                {props.problem}
                            </p>
                            <a href="#" className="md:text-sm text-xs font-semibold block text-right mt-4 underline"> Read more</a>
                        </div>
                    </div>
                </div>
                <div className="w-0 h-auto border-l-2 border-white "></div>
                <div className=" w-full flex flex-col justify-center">
                    <div>
                        <p className="font-bold text-white text-xl text-center mb-6"> SOLUTION</p>
                        <div className="md:w-4/5 mx-auto">
                            <p className="md:text-lg text-xs md:leading-6 text-justify">
                                {props.solution}
                            </p>
                            <a href="#" className="md:text-sm text-xs font-semibold block text-right mt-4 underline"> Read more</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </>)
}
export default OurContibution;